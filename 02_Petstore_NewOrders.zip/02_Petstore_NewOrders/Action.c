Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	web_cache_cleanup();
	
    web_cleanup_auto_headers();
    
    web_cleanup_cookies();
	
	web_set_max_html_param_len("9999999");
	

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Welcome to JPetStore 6",
		LAST);


	lr_start_transaction("PetStore_NewOrder_01_Launch");

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	
	lr_end_transaction("PetStore_NewOrder_01_Launch",LR_AUTO);

	lr_think_time(ThinkTime);
	
    //D34A47FCA3601B53CA1D2905AEB91082
	web_reg_save_param_ex(
		"ParamName=c_jsessionid",
		"LB=JSESSIONID=",
		"RB=;",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"RequestUrl=*/Catalog.action*",
		LAST);
		
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Search",
		LAST);
		
	lr_start_transaction("PetStore_NewOrder_02_Click_EnterStore");

	web_url("Enter the Store", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_NewOrder_02_Click_EnterStore",LR_AUTO);

	lr_think_time(ThinkTime);
	
    //pYNNP8bk-S7p1YgNNxhTmQrNz8eTQ2CPBQoEuPIfXHEouQW1Ht8-urC5e68kLUgcZMhe4_U12l6rS7RW4i6GXw9u9Vc_137belTXeqNDQ7U
    web_reg_save_param_ex(
		"ParamName=c_sourcePage",
		"LB=name=\"_sourcePage\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

  //dkMeY2MhfefUei_hQn92YE7p0hth01687ebq6DjzScJ-MrUeDQEg0UlGxC3gUGy8
  web_reg_save_param_ex(
		"ParamName=c_fp",
		"LB=name=\"__fp\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
  
   web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Register Now!",
		LAST);
  
  lr_start_transaction("PetStore_NewOrder_03_Click_Signin");

	web_url("Sign In",
		"URL=https://petstore.octoperf.com/actions/Account.action;jsessionid={c_jsessionid}?signonForm=",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Catalog.action",
		"Snapshot=t4.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("PetStore_NewOrder_03_Click_Signin",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=My Account",
		LAST);

	lr_start_transaction("PetStore_NewOrder_04_Login");

	web_submit_data("Account.action",
		"Action=https://petstore.octoperf.com/actions/Account.action",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Account.action;jsessionid={c_jsessionid}?signonForm=",
		"Snapshot=t5.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=username", "Value={p_username}", ENDITEM,
		"Name=password", "Value={p_password}", ENDITEM,
		"Name=signon", "Value=Login", ENDITEM,
		"Name=_sourcePage", "Value={c_sourcePage}", ENDITEM,
		"Name=__fp", "Value={c_fp}", ENDITEM,
		LAST);

	lr_end_transaction("PetStore_NewOrder_04_Login",LR_AUTO);
	
	lr_think_time(ThinkTime);
	

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Product ID",
		LAST);
	
	lr_start_transaction("PetStore_NewOrder_05_Click_Link");

	web_url("sm_cats.gif", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId={p_category}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_NewOrder_05_Click_Link",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
		web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=addItemToCart",
		LAST);

	lr_start_transaction("PetStore_NewOrder_06_Select_ProductID");

	web_url("{p_productID}", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId={p_productID}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId={p_category}", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_NewOrder_06_Select_ProductID",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Shopping Cart",
		LAST);

	lr_start_transaction("PetStore_NewOrder_07_Click_AddToCart_Button");

	web_url("Add to Cart", 
		"URL=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId={p_workingID}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId={p_productID}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_NewOrder_07_Click_AddToCart_Button",LR_AUTO);

    lr_think_time(ThinkTime);
    
//DZe2cLBSXDKeGWIGT1df8CQK-ziylDwLljXzVqG0D8kHRUGxHAktSVdENLX20LnTAlagSfpsjq3hGO1rJUVifgkWEvYwk648SIhn2ckj4aqK_IAXyso6IQ==
	web_reg_save_param_ex(
		"ParamName=c_fp_1",
		"LB=name=\"__fp\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

   //SoSnh8kKrTD-L6GhHtIT8KxnM--9BZsU50zWOjkX2iIu1_1cHoMPG2Z43PQBV1I1gGTpGifWExOHw-rWUoR9lXmUztD7FLBVXUCkXM9_vLU
   web_reg_save_param_ex(
		"ParamName=c_sourcePage_1",
		"LB=name=\"_sourcePage\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
   
   web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Payment Details",
		LAST);
		
	lr_start_transaction("PetStore_NewOrder_08_Click_ProceedToCheckout_Button");


	web_url("Proceed to Checkout",
		"URL=https://petstore.octoperf.com/actions/Order.action?newOrderForm=",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId={p_workingID}",
		"Snapshot=t9.inf",
		"Mode=HTML",
		LAST);



	lr_end_transaction("PetStore_NewOrder_08_Click_ProceedToCheckout_Button",LR_AUTO);
     
    lr_think_time(ThinkTime);
    
    web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Please confirm the information ",
		LAST);

	lr_start_transaction("PetStore_NewOrder_09_Enter_PaymentDetails_Continue");

	web_submit_data("Order.action",
		"Action=https://petstore.octoperf.com/actions/Order.action",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrderForm=",
		"Snapshot=t10.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=order.cardType", "Value=Visa", ENDITEM,
		"Name=order.creditCard", "Value=999 9999 9999 9999", ENDITEM,
		"Name=order.expiryDate", "Value=12/03", ENDITEM,
		"Name=order.billToFirstName", "Value=ABC", ENDITEM,
		"Name=order.billToLastName", "Value=XYX", ENDITEM,
		"Name=order.billAddress1", "Value=901 San Antonio Road", ENDITEM,
		"Name=order.billAddress2", "Value=MS UCUP02-206", ENDITEM,
		"Name=order.billCity", "Value=Palo Alto", ENDITEM,
		"Name=order.billState", "Value=CA", ENDITEM,
		"Name=order.billZip", "Value=94303", ENDITEM,
		"Name=order.billCountry", "Value=USA", ENDITEM,
		"Name=newOrder", "Value=Continue", ENDITEM,
		"Name=_sourcePage", "Value={c_sourcePage_1}", ENDITEM,
		"Name=__fp", "Value={c_fp_1}", ENDITEM,
		LAST);

	lr_end_transaction("PetStore_NewOrder_09_Enter_PaymentDetails_Continue",LR_AUTO);
	
	lr_think_time(ThinkTime);

	//Order #3142
	web_reg_save_param_ex(
		"ParamName=c_orderId",
		"LB=Order #",
		"RB=2024/07",
		LAST);
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=order has been submitted",
		LAST);

	lr_start_transaction("PetStore_NewOrder_10_OrderDetails_Click_Confirm");

	web_url("Confirm", 
		"URL=https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_NewOrder_10_OrderDetails_Click_Confirm",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
		web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=User Information",
		LAST);

	lr_start_transaction("PetStore_NewOrder_11_Click_MyAccount");

	web_url("My Account", 
		"URL=https://petstore.octoperf.com/actions/Account.action?editAccountForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_NewOrder_11_Click_MyAccount",LR_AUTO);

	lr_think_time(ThinkTime);

	lr_start_transaction("PetStore_NewOrder_12_Click_MyOrders");


	web_url("My Orders", 
		"URL=https://petstore.octoperf.com/actions/Order.action?listOrders=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action?editAccountForm=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_NewOrder_12_Click_MyOrders",LR_AUTO);
    
	lr_think_time(ThinkTime);

	lr_start_transaction("PetStore_NewOrder_13_Select_OrderID");

	web_url("1090",
		"URL=https://petstore.octoperf.com/actions/Order.action?viewOrder=&orderId={orderId}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Order.action?listOrders=",
		"Snapshot=t14.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("PetStore_NewOrder_13_Select_OrderID",LR_AUTO);
	
	lr_think_time(ThinkTime);

	lr_start_transaction("PetStore_NewOrder_14_Click_SignOut");

	web_url("Sign Out",
		"URL=https://petstore.octoperf.com/actions/Account.action?signoff=",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Order.action?viewOrder=&orderId={orderId}",
		"Snapshot=t15.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("PetStore_NewOrder_14_Click_SignOut",LR_AUTO);

	return 0;
}