Action()
{

	FILE *fp;
    char filename[] = "C:\\Common_Params\\Bluestream\\Order_Details.txt"; // File name to save captured value
    int iteration;
    
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Fish",
		LAST);

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Product ID",
		LAST);

	lr_start_transaction("PetStore_Add&Update_05_Click_Fish");

	web_url("sm_fish.gif", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=FISH", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_05_Click_Fish",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=addItemToCart",
		LAST);

	lr_start_transaction("PetStore_Add&Update_06_Select_Product");

	web_url("FI-FW-02", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=FI-FW-02", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=FISH", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_06_Select_Product",LR_AUTO);
	
	lr_think_time(ThinkTime);

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Shopping Cart",
		LAST);

	lr_start_transaction("PetStore_Add&Update_07_Fish_Click_AddToCart");

	web_url("Add to Cart", 
		"URL=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-20", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=FI-FW-02", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_07_Fish_Click_AddToCart",LR_AUTO);
	
	lr_think_time(ThinkTime);

    web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Reptiles",
		LAST);
	
	lr_start_transaction("PetStore_Add&Update_08_Click_Reptiles");

	web_url("sm_reptiles.gif", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=REPTILES", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-20", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_08_Click_Reptiles",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
	 web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Return to REPTILES",
		LAST);

	lr_start_transaction("PetStore_Add&Update_09_Select_Product2");

	web_url("RP-SN-01", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=RP-SN-01", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=REPTILES", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_09_Select_Product2",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
	//Qy1oiQbSTl6kAcpfSv1R7GWetMF8efulOnNO5dhPILfFHcrz9DWRi3SGFWkiSVuLRCYccvA_A3mD58p1hx8xn55Oadcq-E8S
	web_reg_save_param_ex(
		"ParamName=c_sourcePage_1",
		"LB=name=\"_sourcePage\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

    //0aSTaqlBJmXdrafGLi1aOZpzJHbAFSJ5QsafhXmRKlpRbISAgaND92uqonn5f2TO
	web_reg_save_param_ex(
		"ParamName=c_fp_1",
		"LB=name=\"__fp\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
    
    web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Shopping Cart",
		LAST);

	lr_start_transaction("PetStore_Add&Update_10_Rattlesnake_Click_AddToCart");

	web_url("Add to Cart_2", 
		"URL=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-11", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=RP-SN-01", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("PetStore_Add&Update_10_Rattlesnake_Click_AddToCart",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Sub Total:",
		LAST);

	lr_start_transaction("PetStore_Add&Update_11_ShoppingCart_Click_UpdateCart");

	web_submit_data("Cart.action",
		"Action=https://petstore.octoperf.com/actions/Cart.action",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-11",
		"Snapshot=t11.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=EST-20", "Value={p_quantity1}", ENDITEM,
		"Name=EST-11", "Value={p_quantity2}", ENDITEM,
		"Name=updateCartQuantities", "Value=Update Cart", ENDITEM,
		"Name=_sourcePage", "Value={c_sourcePage_1}", ENDITEM,
		"Name=__fp", "Value={c_fp_1}", ENDITEM,
		LAST);

	lr_end_transaction("PetStore_Add&Update_11_ShoppingCart_Click_UpdateCart",LR_AUTO);
	
	lr_think_time(ThinkTime);

	//XQzAdWVaeL44P11q7kAoJPDPlyXkkqblthkhyBJFrhl0moyhmjnA33v4SmjjNwMunlUEp0B7lNUvej3QueLRpsRGepmWCpm2m25DKx0t1TmUXqzfJDL12w=
		web_reg_save_param_ex(
		"ParamName=c_fp_2",
		"LB=name=\"__fp\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	//pAvQHPodMfSrUtZA2_vTkbRi8T61aS_1UEcOTZtBMobEZMgXsSs1CcHfE6R5UV3ziWul39Pmazu1lKZxrJFoNOpKfVOxzElqo-c6Cd982b8
	web_reg_save_param_ex(
		"ParamName=c_sourcePage_2",
		"LB=name=\"_sourcePage\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Payment Details",
		LAST);

	lr_start_transaction("PetStore_Add&Update_12_Click_ProceedToCheckout");
		
	web_url("Proceed to Checkout", 
		"URL=https://petstore.octoperf.com/actions/Order.action?newOrderForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Cart.action", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_12_Click_ProceedToCheckout",LR_AUTO);
	
	lr_think_time(ThinkTime);

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Please confirm the information ",
		LAST);

	lr_start_transaction("PetStore_Add&Update_13_PaymentDetails_Click_Continue");

	web_submit_data("Order.action",
		"Action=https://petstore.octoperf.com/actions/Order.action",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrderForm=",
		"Snapshot=t13.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=order.cardType", "Value=Visa", ENDITEM,
		"Name=order.creditCard", "Value=999 9999 9999 9999", ENDITEM,
		"Name=order.expiryDate", "Value=12/03", ENDITEM,
		"Name=order.billToFirstName", "Value=ABC", ENDITEM,
		"Name=order.billToLastName", "Value={p_lastname}", ENDITEM,
		"Name=order.billAddress1", "Value=901 San Antonio Road", ENDITEM,
		"Name=order.billAddress2", "Value=MS UCUP02-206", ENDITEM,
		"Name=order.billCity", "Value=Palo Alto", ENDITEM,
		"Name=order.billState", "Value=CA", ENDITEM,
		"Name=order.billZip", "Value=94303", ENDITEM,
		"Name=order.billCountry", "Value=USA", ENDITEM,
		"Name=newOrder", "Value=Continue", ENDITEM,
		"Name=_sourcePage", "Value={c_sourcePage_2}", ENDITEM,
		"Name=__fp", "Value={c_fp_2}", ENDITEM,
		LAST);

	lr_end_transaction("PetStore_Add&Update_13_PaymentDetails_Click_Continue",LR_AUTO);
	
	lr_think_time(ThinkTime);

	web_reg_save_param_ex(
		"ParamName=c_paymentamount",
		"LB=Total: ",
		"RB=</th>",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=c_orderId",
		"LB=Order #",
		"RB=2024/07",
		LAST);

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=order has been submitted",
		LAST);
	
	lr_start_transaction("PetStore_Add&Update_14_Order_Click_Continue");

	web_url("Confirm", 
		"URL=https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_14_Order_Click_Continue",LR_AUTO);
	
	lr_think_time(ThinkTime);

	//fEnk47QOL92XeCKssmIl6DSqRQh0KARox2v3Up7R5hLdbnq0ixnZyBR9cxvF2zYyKkns9vs76qNvUcQFqnDavCJGqRPChNoGquwL6VKClos3vhXPUZuHOw==
    web_reg_save_param_ex(
		"ParamName=c_sourcePage_3",
		"LB=name=\"_sourcePage\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	//HtCGOW1HxjeN-wd0s0isyVkrmjObVPzMo9-mGV3iaiR10xJyVZ9m97fR9cj7_mu7oA7U_W825mz8JRzmAVT9WgnhpqaYNhxmRXpgbAMBNPQEozOQeFwt8ri8M-akEFUiIE4Jun-XJMSeHb1pMCkGYS5eHpgObJqpDiOQT8DwFqBJp1Rj9R7FExWkPMwDz4oA
	web_reg_save_param_ex(
		"ParamName=c_fp_3",
		"LB=name=\"__fp\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=User Information",
		LAST);

	lr_start_transaction("PetStore_Add&Update_15_Click_MyAccount");

	web_url("My Account", 
		"URL=https://petstore.octoperf.com/actions/Account.action?editAccountForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_15_Click_MyAccount",LR_AUTO);

    lr_think_time(ThinkTime);	
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Profile Information",
		LAST);

	lr_start_transaction("PetStore_Add&Update_16_Update_AccountInformation_Save");

	web_submit_data("Account.action_2",
		"Action=https://petstore.octoperf.com/actions/Account.action",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Account.action?editAccountForm=",
		"Snapshot=t16.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=password", "Value=", ENDITEM,
		"Name=repeatedPassword", "Value=", ENDITEM,
		"Name=account.firstName", "Value={p_firstname}", ENDITEM,
		"Name=account.lastName", "Value={p_lastname}", ENDITEM,
		"Name=account.email", "Value={p_email}", ENDITEM,
		"Name=account.phone", "Value={p_phone}", ENDITEM,
		"Name=account.address1", "Value=901 San Antonio Road", ENDITEM,
		"Name=account.address2", "Value=MS UCUP02-206", ENDITEM,
		"Name=account.city", "Value=Palo Alto", ENDITEM,
		"Name=account.state", "Value=CA", ENDITEM,
		"Name=account.zip", "Value=94307", ENDITEM,
		"Name=account.country", "Value=USA", ENDITEM,
		"Name=account.languagePreference", "Value=english", ENDITEM,
		"Name=account.favouriteCategoryId", "Value=REPTILES", ENDITEM,
		"Name=editAccount", "Value=Save Account Information", ENDITEM,
		"Name=_sourcePage", "Value={c_sourcePage_3}", ENDITEM,
		"Name=__fp", "Value={c_fp_3}", ENDITEM,
		LAST);

	lr_end_transaction("PetStore_Add&Update_16_Update_AccountInformation_Save",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
	
	

  // Open the file for writing 
    fp = fopen(filename, "w");

    if (fp == NULL) {
        lr_error_message("Cannot open file %s", filename);
        return -1;
    }
    
        fprintf(fp, "Order Details:\n");
        fprintf(fp, "User ID: %s\n", lr_eval_string("{p_username}"));
        fprintf(fp, "Payment Amount: %s\n", lr_eval_string("{c_paymentamount}"));
        fprintf(fp, "Order ID: %s\n", lr_eval_string("{c_orderId}"));
        fprintf(fp, "--------------------------------\n");


    // Close the file
    fclose(fp);

    lr_output_message("Captured values for %d iterations successfully saved to %s", filename);

	
    return 0; 
}