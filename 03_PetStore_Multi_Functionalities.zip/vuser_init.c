vuser_init()
{
	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	web_cache_cleanup();
	
    web_cleanup_auto_headers();
    
    web_cleanup_cookies();
	
	web_set_max_html_param_len("9999999");
	

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Welcome to JPetStore 6",
		LAST);
	
	lr_start_transaction("PetStore_Add&Update_01_Launch");

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("PetStore_Add&Update_01_Launch",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
	//c_jsessionid
	web_reg_save_param_ex(
		"ParamName=c_jsessionid",
		"LB=jsessionid=",
		"RB=\">Sign In",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/Catalog.action*",
		LAST);
		
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Search",
		LAST);
	
	lr_start_transaction("PetStore_Add&Update_02_EnterTheStore");

	web_url("Enter the Store", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_02_EnterTheStore",LR_AUTO);
	
	lr_think_time(ThinkTime);

  //ASK3W8bJt7h-NgYWNPlRfAOyrn_en6Ud8qB2vSe9kODmSXttvcqV6WhJcJJbcBQQHXaYEZc0p6H5TUzE1-Ga1rG5ehVnsDWPRIcl0Tb9pf8
	web_reg_save_param_ex(
		"ParamName=c_sourcePage",
		"LB=name=\"_sourcePage\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

   //tYwl9lw_Cc_I9BdU6zgOvwJr8uXnkNiOTncpsiwxtRbIF5Q3-9Gwc09dJcg0YgXC
	web_reg_save_param_ex(
		"ParamName=c_fp",
		"LB=name=\"__fp\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
   
   
   web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Register Now!",
		LAST);
		
	lr_start_transaction("PetStore_Add&Update_03_Click_Signin");

    web_url("Sign In", 
		"URL=https://petstore.octoperf.com/actions/Account.action;jsessionid={c_jsessionid}?signonForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_03_Click_Signin",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=My Account",
		LAST);

	lr_start_transaction("PetStore_Add&Update_04_Login");

	web_submit_data("Account.action",
		"Action=https://petstore.octoperf.com/actions/Account.action",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Account.action;jsessionid={c_jsessionid}?signonForm=",
		"Snapshot=t4.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=username", "Value={p_username}", ENDITEM,
		"Name=password", "Value={p_password}", ENDITEM,
		"Name=signon", "Value=Login", ENDITEM,
		"Name=_sourcePage", "Value={c_sourcePage}", ENDITEM,
		"Name=__fp", "Value={c_fp}", ENDITEM,
		LAST);

	lr_end_transaction("PetStore_Add&Update_04_Login",LR_AUTO);
	
	lr_think_time(ThinkTime);
	
	return 0;
}
