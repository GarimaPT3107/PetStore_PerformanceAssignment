vuser_end()
{
	web_reg_find(
		"Text=Sign In",
		"SaveCount=SignCount",
		"Search=Body",
		LAST);

	lr_start_transaction("PetStore_Add&Update_17_Signout");

	web_url("Sign Out", 
		"URL=https://petstore.octoperf.com/actions/Account.action?signoff=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PetStore_Add&Update_17_Signout",LR_AUTO);
	
	return 0;
}
