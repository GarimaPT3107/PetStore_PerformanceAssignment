Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	web_cache_cleanup();
	
    web_cleanup_auto_headers();
    
    web_cleanup_cookies();
	
	web_set_max_html_param_len("9999999");
	

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");
	
		web_reg_find(
		"Text=Welcome to JPetStore 6",
		"SaveCount=WelcomeCount",
		"Search=Body",
		LAST);
	
	lr_start_transaction("PetStore_UserCreation_01_Launch");

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	if (lr_eval_string("{WelcomeCount}") == 0) {
    lr_end_transaction("PetStore_UserCreation_01_Launch", LR_FAIL);
    lr_error_message("Home page did not load successfully.");
    } else {
    lr_end_transaction("PetStore_UserCreation_01_Launch", LR_PASS);
    }
	
	//35822FB2C9E3CE5_D9D5C0C813272D680
	
	web_reg_save_param_ex(
		"ParamName=c_jsessionid",
		"LB=JSESSIONID=",
		"RB=;",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"RequestUrl=*/Catalog.action*",
		LAST);
	
	web_reg_find(
		"Text=Search",
		"SaveCount=Searchcount",
		"Search=Body",
		LAST);

	lr_start_transaction("PetStore_UserCreation_02_Click_EntertheStore_Link");

	web_url("Enter the Store", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	if (lr_eval_string("{Searchcount}") == 0) {
    lr_end_transaction("PetStore_UserCreation_02_Click_EntertheStore_Link", LR_FAIL);
    lr_error_message("Expected search option text not found. Transaction failed.");
    } else {
    lr_end_transaction("PetStore_UserCreation_02_Click_EntertheStore_Link", LR_PASS);
    }
	
	
	web_reg_find(
		"Text=Register Now!",
		"SaveCount=Registercount",
		"Search=Body",
		LAST);

	lr_start_transaction("PetStore_UserCreation_03_Click_SignIn");

	web_url("Sign In",
		"URL=https://petstore.octoperf.com/actions/Account.action;jsessionid={c_jsessionid}?signonForm=",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Catalog.action",
		"Snapshot=t3.inf",
		"Mode=HTML",
		LAST);
	
	if (lr_eval_string("{Registercount}") == 0) {
    lr_end_transaction("PetStore_UserCreation_03_Click_SignIn", LR_FAIL);
    lr_error_message("Expected RegisterNow text not found. Transaction failed.");
    } else {
    lr_end_transaction("PetStore_UserCreation_03_Click_SignIn", LR_PASS);
    }
	
	lr_think_time(ThinkTime);


	//OmX4TifDpcyBaA9roTnRJsXqjYc-4smGZzwSvBEFGgOBGMH9dWo0Sbi2ENiYv-rEQkwLF7xl-Kdql1Fz_SH5MJy0IhulVStniZ9Gh3uucn4=
	web_reg_save_param_ex(
		"ParamName=c_soucepage",
		"LB=name=\"_sourcePage\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	//y0d-YI5EqXTTkqwq6BD6PRbAtJVuRtsHJSuJRBqaf4EyVgXy_J-NL0Z_loD5RO4EYzhX-mtTkjHgPOOlQDHxDEPSYi379IrOz58YYTemABFhyccrFM2n7X-cUpn5h6K2x_fiokeMVxiHnw_3rngwE9WcgqDr3MSri3t6yVCc2_zXdbqg0v_cMqLdQDA2jl4
    web_reg_save_param_ex(
		"ParamName=c_fpID",
		"LB=name=\"__fp\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	web_reg_find(
		"Text=User Information",
		"SaveCount=UserCount",
		"Search=Body",
		LAST);

	lr_start_transaction("PetStore_UserCreation_04_Click_RegisterNow");

	web_url("Register Now!",
		"URL=https://petstore.octoperf.com/actions/Account.action?newAccountForm=",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Account.action;jsessionid={c_jsessionid}?signonForm=",
		"Snapshot=t4.inf",
		"Mode=HTML",
		LAST);

	if (lr_eval_string("{UserCount}") == 0) {
    lr_end_transaction("PetStore_UserCreation_04_Click_RegisterNow", LR_FAIL);
    lr_error_message("Expected user text not found. Transaction failed.");
    } else {
    lr_end_transaction("PetStore_UserCreation_04_Click_RegisterNow", LR_PASS);
    }
	
	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");
		
	web_reg_find(
		"Text=Account Information",
		"SaveCount=AccountInfoCount",
		"Search=Body",
		LAST);

	lr_start_transaction("PetStore_UserCreation_05_Enter_UserInformation");

	web_submit_data("Account.action_2", 
		"Action=https://petstore.octoperf.com/actions/Account.action", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action?newAccountForm=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value={p_username}", ENDITEM, 
		"Name=password", "Value={p_password}", ENDITEM, 
		"Name=repeatedPassword", "Value={p_password}", ENDITEM, 
		"Name=account.firstName", "Value={p_firstname}", ENDITEM, 
		"Name=account.lastName", "Value={p_lastname}", ENDITEM, 
		"Name=account.email", "Value={p_firstname}.{p_lastname}@gmail.com", ENDITEM, 
		"Name=account.phone", "Value=12345590", ENDITEM, 
		"Name=account.address1", "Value=Suite 252 6483 Maribel Mall", ENDITEM, 
		"Name=account.address2", "Value=", ENDITEM, 
		"Name=account.city", "Value=Kellyefurt", ENDITEM, 
		"Name=account.state", "Value=SD", ENDITEM, 
		"Name=account.zip", "Value=55111", ENDITEM, 
		"Name=account.country", "Value=US", ENDITEM, 
		"Name=account.languagePreference", "Value=english", ENDITEM, 
		"Name=account.favouriteCategoryId", "Value=FISH", ENDITEM, 
		"Name=account.listOption", "Value=true", ENDITEM, 
		"Name=account.bannerOption", "Value=true", ENDITEM, 
		"Name=newAccount", "Value=Save Account Information", ENDITEM, 
		"Name=_sourcePage", "Value={c_soucepage}", ENDITEM, 
		"Name=__fp", "Value={c_fpID}", ENDITEM, 
		LAST);

   if (lr_eval_string("{AccountInfoCount}") == 0) {
    lr_end_transaction("PetStore_UserCreation_05_Enter_UserInformation", LR_FAIL);
    lr_error_message("Expected Account text not found. Transaction failed.");
    } else {
    lr_end_transaction("PetStore_UserCreation_05_Enter_UserInformation", LR_PASS);
    }
	
	//Z_VCv8cSGlrGAgq0Kblk5T5ET2YdrQjjNrCobgv3V4HSMHc7j1ffHI0bZEngycYpScWEzyZXa71UKm3ukCk0ESl7Hu4W1wnl4wl1y-k0VS8=
	web_reg_save_param_ex(
		"ParamName=c_soucepage2",
		"LB=name=\"_sourcePage\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
    //it36FLWizGSBN5KJHZGZrIll5W1WlU8eoQ0wueJAgwpWtPoJ_Dyd5SlyrPRtmpOs
		
    web_reg_save_param_ex(
		"ParamName=c_fpID2",
		"LB=name=\"__fp\" value=\"",
		"RB=\" ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
    
      web_reg_find(
		"Text=Please enter your username and password.",
		"SaveCount=IdCount",
		"Search=Body",
		LAST);

	lr_start_transaction("PetStore_UserCreation_06_Click_SignIn2");

	web_url("Sign In_2", 
		"URL=https://petstore.octoperf.com/actions/Account.action?signonForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);
	
	if (lr_eval_string("{IdCount}") == 0) {
    lr_end_transaction("PetStore_UserCreation_06_Click_SignIn2", LR_FAIL);
    lr_error_message("Expected user text not found. Transaction failed.");
    } else {
    lr_end_transaction("PetStore_UserCreation_06_Click_SignIn2", LR_PASS);
    }
 
    web_reg_find(
		"Text=Sign Out",
		"SaveCount=SignCount",
		"Search=Body",
		LAST);
    
	lr_start_transaction("PetStore_UserCreation_07_Login");

	web_submit_data("Account.action_3", 
		"Action=https://petstore.octoperf.com/actions/Account.action", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action?signonForm=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={p_username}", ENDITEM, 
		"Name=password", "Value={p_password}", ENDITEM, 
		"Name=signon", "Value=Login", ENDITEM, 
		"Name=_sourcePage", "Value={c_soucepage2}", ENDITEM, 
		"Name=__fp", "Value={c_fpID2}", ENDITEM, 
		LAST);

	if (lr_eval_string("{SignCount}") == 0) {
    lr_end_transaction("PetStore_UserCreation_07_Login", LR_FAIL);
    lr_error_message("Expected user text not found. Transaction failed.");
    } else {
    lr_end_transaction("PetStore_UserCreation_07_Login", LR_PASS);
    }
	
	web_reg_find(
		"Text=My Account",
		"SaveCount=AccountCount",
		"Search=Body",
		LAST);

	lr_start_transaction("PetStore_UserCreation_08_Click_MyAccount");
    
	web_url("My Account", 
		"URL=https://petstore.octoperf.com/actions/Account.action?editAccountForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);
	
	if (lr_eval_string("{AccountCount}") == 0) {
    lr_end_transaction("PetStore_UserCreation_08_Click_MyAccount", LR_FAIL);
    lr_error_message("Expected text not found. Transaction failed.");
    } else {
    lr_end_transaction("PetStore_UserCreation_08_Click_MyAccount", LR_PASS);
    }
	
	web_reg_find(
		"Text=Sign In",
		"SaveCount=SignCount",
		"Search=Body",
		LAST);

	lr_start_transaction("PetStore_UserCreation_09_Signout");
    
	web_url("My Account", 
		"URL=https://petstore.octoperf.com/actions/Account.action?editAccountForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);
	
	if (lr_eval_string("{SignCount}") == 0) {
    lr_end_transaction("PetStore_UserCreation_09_Signout", LR_FAIL);
    lr_error_message("Expected text not found. Transaction failed.");
    } else {
    lr_end_transaction("PetStore_UserCreation_09_Signout", LR_PASS);
    }

	return 0;
}